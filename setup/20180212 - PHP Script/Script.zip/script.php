<?php
require __DIR__ . '/vendor/autoload.php';

//Define the database information
define('DB_HOST','localhost');      //Host
define('DB_USER','root');           //Username
define('DB_PASS','');               //Password

define('DB_PREFIX_ECOBIZ','ecobiz_');
define('DB_PREFIX_GREENBIZ','greenbiz_');
define('DB_PREFIX_TEST','test_');

$db = new MysqliDb (DB_HOST, DB_USER, DB_PASS);

//Table List
$tables = array(
    [
        'database' => 'core',
        'table' => 'client'
    ],
    [
        'database' => 'core',
        'table' => 'client_contact'
    ],
    [
        'database' => 'checklist',
        'table' => 'checklist'
    ],
    [
        'database' => 'checklist',
        'table' => 'certification_level'
    ],
    [
        'database' => 'checklist',
        'table' => 'page'
    ],
    [
        'database' => 'checklist',
        'table' => 'page_section'
    ],
    [
        'database' => 'checklist',
        'table' => 'page_section_2_page'
    ],
    [
        'database' => 'checklist',
        'table' => 'question'
    ],
    [
        'database' => 'checklist',
        'table' => 'answer'
    ],
    [
        'database' => 'checklist',
        'table' => 'answer_string'
    ],
    [
        'database' => 'checklist',
        'table' => 'answer_2_question'
    ],
    [
        'database' => 'checklist',
        'table' => 'report_section'
    ],
    [
        'database' => 'checklist',
        'table' => 'action'
    ],
    [
        'database' => 'checklist',
        'table' => 'action_2_answer'
    ],
    [
        'database' => 'checklist',
        'table' => 'resource'
    ],
    [
        'database' => 'checklist',
        'table' => 'resource_type'
    ],
    [
        'database' => 'checklist',
        'table' => 'confirmation'
    ],
    [
        'database' => 'checklist',
        'table' => 'audit'
    ],
    [
        'database' => 'checklist',
        'table' => 'commitment'
    ],
    [
        'database' => 'checklist',
        'table' => 'client_checklist'
    ],
    [
        'database' => 'checklist',
        'table' => 'client_checklist_score'
    ],
    [
        'database' => 'checklist',
        'table' => 'client_commitment'
    ],
    [
        'database' => 'checklist',
        'table' => 'client_page_note'
    ],
    [
        'database' => 'checklist',
        'table' => 'client_result'
    ],
    [
        'database' => 'core',
        'table' => 'client_type'
    ]
);

$max_id = array();

//Get Max Id of Each Table
for ($i = 0; $i < count($tables); $i++) {
    $result = $db->orderBy($tables[$i]['table']."_id","desc")
        ->getOne(DB_PREFIX_GREENBIZ.$tables[$i]['database'].'.'.$tables[$i]['table'],$tables[$i]['table'].'_id');
    $max_id[$tables[$i]['table']."_id"] = $result[$tables[$i]['table']."_id"];
}

for ($i = 0; $i < count($tables); $i++) {
    //Get Rows
    $result = $db->get(DB_PREFIX_ECOBIZ.$tables[$i]['database'].'.'.$tables[$i]['table']);
    if (count($result) > 0) {
        //Get ID keys to add
        $keys = array_keys($result[0]);
        $common = array_intersect_key($max_id, $result[0]);
        $common_keys = array_keys($common);

        //Insert to the table
        for ($j = 0; $j < count($result); $j++) {
            for ($k = 0; $k < count($common_keys); $k++) {
                $result[$j][$common_keys[$k]] += $max_id[$common_keys[$k]];
            }
            $db->insert(DB_PREFIX_TEST.$tables[$i]['database'].'.'.$tables[$i]['table'], $result[$j]);
        }
    }
}

?>
